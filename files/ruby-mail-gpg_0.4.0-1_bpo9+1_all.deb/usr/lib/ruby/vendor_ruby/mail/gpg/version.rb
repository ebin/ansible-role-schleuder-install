module Mail
  module Gpg
    VERSION = "0.4.0"
  end
end
