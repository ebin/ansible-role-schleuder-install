module Schleuder
  VERSION = '3.3.0'
end
