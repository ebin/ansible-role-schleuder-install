class Thor
  VERSION = "0.19.4"
end
