require 'rails_helper'

describe List do
  it { is_expected.to respond_to :subscriptions }
end
