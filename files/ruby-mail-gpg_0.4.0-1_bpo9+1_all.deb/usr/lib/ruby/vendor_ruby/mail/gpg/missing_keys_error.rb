module Mail
  module Gpg
    class MissingKeysError < StandardError
    end
  end
end
