# frozen_string_literal: true

module Bundler
  def self.require_thor_actions
    Kernel.send(:require, "thor/actions")
  end
end
require "thor"
