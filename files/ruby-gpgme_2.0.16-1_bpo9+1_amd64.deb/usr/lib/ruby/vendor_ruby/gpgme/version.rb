module GPGME
  # The version of GPGME ruby binding you are using
  VERSION = "2.0.16"
end
