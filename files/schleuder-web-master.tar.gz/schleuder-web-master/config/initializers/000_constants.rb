API_REQUIRED = !! (defined?(Rails::Server) || defined?(Rails::Console))
