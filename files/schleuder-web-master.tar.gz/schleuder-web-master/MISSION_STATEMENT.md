# Schleuder's Mission Statement

We give our time and knowledge to build and maintain this project in order to help people with their daily private communication and in the struggle for their personal emancipation, social and economic justice and political freedom.

A more human world, in which anyone can be different without fear, is what we strive for.

We work transparently and responsibly, and don't collaborate with surveillance actors.

We do not endorse any form of authoritarian movement or totalitarian system, and wish for that Schleuder may not ever be used to promote or enable them. Instead we are committed to ideas and principles outlined in our [Code of Conduct](https://0xacab.org/schleuder/schleuder-web/blob/master/CODE_OF_CONDUCT.md).

If you do not agree, do not use Schleuder.
